// src/data/filmsAjoutes.js

export const filmsAjoutes = []; // يمكننا استخدام useState محليًا بدلاً من هذا أيضًا
